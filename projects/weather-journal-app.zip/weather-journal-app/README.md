# Weather-Journal App Project

## Overview
This project contains the Weather-Journal-App, part of the Udacity Front End Web Development NanoDegree, by Matt Rauscher.

## Instructions
This project requires running '**server.js**' on Express.js. Open Index.html with the browser and fill the fields before generating. 

